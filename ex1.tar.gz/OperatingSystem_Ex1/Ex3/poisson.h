# pragma once

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

long double factorial(double);
long double px(double, double);